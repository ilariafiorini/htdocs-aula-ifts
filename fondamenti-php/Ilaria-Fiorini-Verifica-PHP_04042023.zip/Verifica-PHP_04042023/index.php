<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verifica PHP del 4 aprile 2023</title>
</head>
<body>

<hr>
<h3>Punto 1</h3>
<hr><br>

<p> Ricerca una località anche inserendo una stringa parziale contenuta
    nel nome della Città o della Provincia
</p><br>

<form action="lista_citta.php" method="POST">
    Stringa di Ricerca: <input type="text" name="searchString" >
    <button>Ricerca</button>
</form>
    
    <p></p><br>
    
</body>
</html>